from django.apps import AppConfig

class MasterListConfig(AppConfig):
    name = 'master_list'
