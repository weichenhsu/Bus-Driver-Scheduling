from django.apps import AppConfig


class DriverScheduleConfig(AppConfig):
    name = 'driver_schedule'
