# -*- coding: utf-8 -*-
"""
Created on Sun Dec 22 14:40:37 2019

@author: user
"""

import json
from operator import attrgetter

routeTime_data = [[],[],[],[],[],[],[]]


rD1 = open('data/route-cal_1.json', encoding = 'utf8')
rD2 = open('data/route-cal_2.json', encoding = 'utf8')
rD3 = open('data/route-cal_3.json', encoding = 'utf8')
rD4 = open('data/route-cal_4.json', encoding = 'utf8')
rD5 = open('data/route-cal_5.json', encoding = 'utf8')
rD6 = open('data/route-cal_6.json', encoding = 'utf8')
rD7 = open('data/route-cal_7.json', encoding = 'utf8')

routeTime_data[0] = json.load(rD1)
routeTime_data[1] = json.load(rD2)
routeTime_data[2] = json.load(rD3)
routeTime_data[3] = json.load(rD4)
routeTime_data[4] = json.load(rD5)
routeTime_data[5] = json.load(rD6)
routeTime_data[6] = json.load(rD7)





# record start & end time of bus route


class routeData_struct:
    def __init_(self):
        self.start = -1
        self.end = -1
        self.dur = -1
        self.sID = -1
        self.rID = -1
        self.dID = -1
        self.rC = -1
    def __str__(self):
        return  str(self.__dict__)

class driver_struct:
    def __init__(self):
        self.dID = -1
        self.end = 0
        self.work = [[],[],[],[],[],[],[]]
        self.dayoff = -1
        self.hasRest = 0
        self.status = -1
        self.workTime = 0
    def __str__(self):
        return  str(self.__dict__)
        



route_id = 0


RD = [[],[],[],[],[],[],[]]



# can change
driverNum = 50
stationNum = 3


# cal rest time
Dayoff = [[0,0,0,0,0,0,0] for j in range(stationNum)]
DayoffLast = [[0,0,0,0,0,0,0] for j in range(stationNum)]
routeA = [[0,0,0,0,0,0,0] for j in range(stationNum)] # [[7 days of this station]]
driverA = [0 for j in range(stationNum)]

# driver state
#[[],[]]
Driver = [[] for j in range(stationNum)] # driver depart by station
DriverList = [] # all driver list

#print(routeA[1][0])

# rest time
avaliableTime = 480 # 480 min
minRestTime = 10; # min
lunchBreak = 60;


# content number
contentNum = [{},{},{},{},{},{},{}]



# 7 times
for k in range(7):
    for i in range(len(routeTime_data[k])):
        contentNum[k][str(routeTime_data[k][i]['route_id'])] = len(routeTime_data[k][i]['content'])
        for j in range(len(routeTime_data[k][i]['content'])):    
            rd = routeData_struct()
            rd.start = routeTime_data[k][i]['content'][j]['time_from']
            rd.end   = routeTime_data[k][i]['content'][j]['time_to']
            rd.dur   = routeTime_data[k][i]['content'][j]['duration']
            rd.sID   = routeTime_data[k][i]['content'][j]['start_station']
            rd.rID   = routeTime_data[k][i]['route_id']
            rd.dID   = -1
            rd.rC    = routeTime_data[k][i]['content'][j]['route_combine']
            RD[k].append(rd)
            routeA[rd.sID][k] += 1
   
'''
for i in range(7):
    for j in range(len(RD[i])):
        print(RD[i][j].__dict__)
        #print("i ",i, "j ",j,"RD ",RD[i][j].start)
'''
 

print(routeA)

# assume driver amount at each station
total_route = 0
Total_Driver = 0
for i in range(stationNum):
    total_route += routeA[i][0]
   

    
for i in range(stationNum):
    driverA[i] = round(routeA[i][0]*driverNum/total_route)
    Total_Driver += driverA[i]
    
if(Total_Driver < driverNum):
    for i in range(driverNum-Total_Driver):
        driverA[i%stationNum] += 1
elif(Total_Driver > driverNum):
    for i in range(Total_Driver-driverNum):
        driverA[i%stationNum] -= 1
 
print(driverA)

# calcilate dayoff driver
        # doff each station each day dayoff 
        # total_doff this station dayoff num in 7 days
total_doff = 0
doff_amount = 0
for i in range(stationNum):
    total_doff = 0
    for j in range(7):
        if(sum(routeA[i]) == 0):
            doff_amount = 0
        else:
            doff_amount = round(driverA[i]*(routeA[i][j]/sum(routeA[i])))
        total_doff += doff_amount
        Dayoff[i][j] = doff_amount
        DayoffLast[i][j] = doff_amount
    if(total_doff < driverA[i]):
        for k in range(driverA[i]-total_doff):
            Dayoff[i][k % 6] += 1
            DayoffLast[i][k % 6] += 1
    elif(total_doff > driverA[i]):        
        for k in range(total_doff - driverA[i]):
            Dayoff[i][k % 6] -= 1
            DayoffLast[i][k % 6] -= 1

    


# init driver state
k = 0

Total_Driver = 0
for i in range(stationNum):
    k = 0
    for j in range(driverA[i]):
        dr = driver_struct()
        dr.dID = Total_Driver
        Total_Driver += 1
        if DayoffLast[i][k] == 0:
            for k in range(7):  
                if DayoffLast[i][k] != 0:
                    DayoffLast[i][k] -= 1
                    break
        else:
            DayoffLast[i][k] -= 1
        dr.dayoff = k    
        dr.end = 0
        dr.work = [[],[],[],[],[],[],[]]
        dr.hasRest = 0
        dr.status = -1
        dr.workTime = 0
        Driver[i].append(dr)    



for i in range(7):
    #sort(RD[i], key=lambda k: k.start)
    RD[i].sort(key = lambda s: s.start)

#for i in range(len(RD[0])):
#    print(RD[0][i].__dict__)

    
    

# cal

def greedy( dr, aT, mRT, lB, rD, wD):
    global Total_Driver
    for i in range(len(rD)):
        last = 0
        cannotwork = 0
        for j in range(driverA[rD[i].sID]):
            
            cannotwork = 0
            if dr[rD[i].sID][j].dayoff == wD:
                cannotwork = 1
                if(j == driverA[rD[i].sID]-1):
                    last == -1
                #print("dID ",dr[rD[i].sID][j].dID,"dayoff ",dr[rD[i].sID][j].dayoff)
                # a day off for a week
                #continue
            elif dr[rD[i].sID][j].workTime >= aT-10: 
                cannotwork = 1
                if(j == driverA[rD[i].sID]-1):
                    last == -1       # 10 : min time for a shift
                # after aT, off work
                dr[rD[i].sID][j].status = 0
                #print("out of work")
                #continue
            elif (aT/2-dr[rD[i].sID][j].workTime) < min(rD[i].dur,70) and dr[rD[i].sID][j].hasRest == 0:
                cannotwork = 1
                if(j == driverA[rD[i].sID]-1):
                    last == -1
                dr[rD[i].sID][j].hasRest = 1
                dr[rD[i].sID][j].end += 60
                #continue
                # if aT/2-worktime < 70 & has not rest, then rest
                # at least a hour off after half of aS
                    # if driver Num available

            
                
            if cannotwork == 0 and (dr[rD[i].sID][j].end+10) < (rD[i].start):
                #print("not in rID",i ," dID ",dr[rD[i].sID][j].dID," route start ",rD[i].start," driver end ",dr[rD[i].sID][j].end)
                # continue working
                dr[rD[i].sID][j].end = (rD[i].end)
                dr[rD[i].sID][j].workTime += (rD[i].dur)
                dr[rD[i].sID][j].work[wD].append(i)  
                rD[i].dID = dr[rD[i].sID][j].dID
                    #print("work id ", i, " dID ",dr[rD[i].sID][j].dID," route start ",rD[i].start," driver end ",dr[rD[i].sID][j].end)
                    
                #print("work RD[",wD,"][",i,"] = dID ",rD[i].dID)
                break
            elif j == (driverA[rD[i].sID]-1+last):
                print("-----not offered id ", i, " route start ",rD[i].start, "sID ",rD[i].sID, "wD ",wD)
                ## 加driver
                ## driver + Driver[rD[i].sID] 
                
                dR = driver_struct()            
                dR.dID = Total_Driver
                Total_Driver += 1
                dR.dayoff = Dayoff[rD[i].sID].index(min(Dayoff[rD[i].sID]))
                #print("dayoff min",min(Dayoff[rD[i].sID]))
                #print("dayoff index",Dayoff[rD[i].sID].index(min(Dayoff[rD[i].sID])))
                dR.end = 0
                dR.work = [[],[],[],[],[],[],[]]
                dR.hasRest = 0
                dR.status = -1
                dR.workTime = 0
                dr[rD[i].sID].append(dR)
                driverA[rD[i].sID] += 1
                Dayoff[rD[i].sID][dR.dayoff] += 1
                
                dr[rD[i].sID][j+1].end = (rD[i].end)
                dr[rD[i].sID][j+1].workTime += (rD[i].dur)
                dr[rD[i].sID][j+1].work[wD].append(i)  
                rD[i].dID = dr[rD[i].sID][j+1].dID
                #print("RD[",wD,"][",i,"] = dID ",rD[i].dID)
                
    return dr, rD



for i in range(7):     
    #print("wD = ",i, "-----------------------------")
    for k in range(len(Driver)):
        for j in range(len(Driver[k])):
            Driver[k][j].end = 0
            Driver[k][j].hasRest = 0
            Driver[k][j].status = 0
            Driver[k][j].workTime = 0
    Driver, RD[i] = greedy( Driver, avaliableTime, minRestTime, lunchBreak, RD[i], i)
    #print()
    
    


for j in range(len(RD)):
    wrap = []
    data = {}
    for key in range(len(contentNum[j])):
        data['route_id'] = key
        data['route_item'] = {}
        route_item = {}
        route_item['0'] = {}
        route_item['1'] = {}
        for i in range(len(RD[j])):
            route_item['0'][str(i)] = RD[j][i].dID
            route_item['1'][str(i)] = RD[j][i].dID
        data['route_item'] = (route_item)
        wrap.append(data)
        filename = 'route_'+str(j)+'.json'
        with open(filename, 'w', encoding='utf-8') as outfile:
            outfile.write(json.dumps(wrap, ensure_ascii=False, indent=4))

            
  

for i in range(len(Driver)):
    for j in range(len(Driver[i])):
        DriverList.append(Driver[i][j])


for i in range(len(DriverList)):
    #print(RD[0][i].__dict__)  
    print(DriverList[i].__dict__)

             
            


            
data = {}
for wD in range(0, 7):
    data['date'] = str(wD)
    
    data['schedule'] = []
    bus_driver_schedule = []
    for i in range(len(DriverList)):
        bus_driver_schedule = []
        for k in range(len(DriverList[i].work[wD])):
            for l in range(len(RD[wD][DriverList[i].work[wD][k]].rC)):
                bus_driver_schedule.append({
                    'route_id': RD[wD][DriverList[i].work[wD][k]].rID,
                    'route_item_id': RD[wD][DriverList[i].work[wD][k]].rC[l]["route_item_id"],
                    'route_detail_id': RD[wD][DriverList[i].work[wD][k]].rC[l]["route_detail_id"],
                })
        data['schedule'].append({
            'bus_driver_id': i,
            'bus_driver_schedule': bus_driver_schedule,
        })
    filename = "driver_"+str(wD)+".json"
    with open(filename, 'w', encoding='utf-8') as outfile:
        outfile.write(json.dumps(data, ensure_ascii=False, indent=4))